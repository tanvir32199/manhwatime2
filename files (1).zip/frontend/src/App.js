import React, { useState } from 'react';
import ReaderView from './ReaderView';
import AdminLogin from './AdminLogin';
import AdminPanel from './AdminPanel';

function App() {
  const [adminToken, setAdminToken] = useState(null);
  const [adminMode, setAdminMode] = useState(false);

  return (
    <div>
      <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <h1>Manhwa Reader</h1>
        <div>
          {adminToken ? (
            <button onClick={() => { setAdminToken(null); setAdminMode(false); }}>Logout</button>
          ) : (
            <button onClick={() => setAdminMode(a => !a)}>
              {adminMode ? "Back to Reader" : "Admin Login"}
            </button>
          )}
        </div>
      </header>
      <main>
        {adminMode ? (
          adminToken 
            ? <AdminPanel adminToken={adminToken} /> 
            : <AdminLogin setAdminToken={setAdminToken} />
        ) : (
          <ReaderView />
        )}
      </main>
    </div>
  );
}

export default App;