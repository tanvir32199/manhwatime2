import React, { useEffect, useState } from 'react';

function ReaderView() {
  const [manhwas, setManhwas] = useState([]);
  const [selected, setSelected] = useState(null);
  const [selectedChapter, setSelectedChapter] = useState(null);

  useEffect(() => {
    fetch('http://localhost:5000/api/manhwas')
      .then(res => res.json())
      .then(setManhwas);
  }, []);

  if (selectedChapter) {
    return (
      <div>
        <button onClick={() => setSelectedChapter(null)}>Back to Chapters</button>
        <h2>{selectedChapter.title}</h2>
        <div>
          {selectedChapter.images.map((img, i) =>
            <img key={i} src={`http://localhost:5000${img}`} alt="" style={{width:'100%',maxWidth:400,margin:'20px auto',display:'block'}} />
          )}
        </div>
      </div>
    );
  }

  if (selected) {
    return (
      <div>
        <button onClick={() => setSelected(null)}>Back</button>
        <h2>{selected.title}</h2>
        <img src={`http://localhost:5000${selected.cover}`} alt="" width={200} />
        <h3>Chapters</h3>
        <ul>
          {selected.chapters.map(ch => (
            <li key={ch.id}>
              <button onClick={() => setSelectedChapter(ch)}>{ch.title}</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }

  return (
    <div>
      <h2>All Manhwas</h2>
      <div style={{display:'flex',flexWrap:'wrap',gap:20}}>
        {manhwas.map(m => (
          <div key={m.id} style={{border:'1px solid #ccc',padding:10,borderRadius:6,maxWidth:180}}>
            <img src={`http://localhost:5000${m.cover}`} alt="" width={120} />
            <h4>{m.title}</h4>
            <div style={{fontSize:12,color:'#555'}}>{m.author}</div>
            <button onClick={() => setSelected(m)}>View</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ReaderView;