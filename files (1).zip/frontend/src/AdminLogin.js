import React, { useState } from 'react';

function AdminLogin({ setAdminToken }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');

  function handleLogin(e) {
    e.preventDefault();
    fetch('http://localhost:5000/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({ username, password })
    })
      .then(res => res.json())
      .then(data => {
        if (data.token) {
          setAdminToken(data.token);
        } else {
          setErr('Login
