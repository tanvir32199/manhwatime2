const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const ADMIN_USER = 'admin';
const ADMIN_PASS = 'password'; // Change this in production!

// In-memory session (for demo)
let session = {};

// Helper to check admin auth
function isAuthenticated(req) {
  const token = req.headers['x-admin-token'];
  return !!(token && session[token]);
}

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    const token = Math.random().toString(36).slice(2);
    session[token] = true;
    return res.json({ token });
  }
  res.status(401).json({ error: 'Invalid credentials' });
});

// Storage config for Multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const { manhwaId, chapterId } = req.body;
    let dir = 'uploads/';
    if (manhwaId && chapterId) dir += `${manhwaId}/${chapterId}/`;
    else if (manhwaId) dir += `${manhwaId}/cover/`;
    else dir += 'temp/';
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Load or initialize manhwa data
const DATA_PATH = path.join(__dirname, 'manhwas.json');
function loadManhwas() {
  if (!fs.existsSync(DATA_PATH)) fs.writeFileSync(DATA_PATH, '[]');
  return JSON.parse(fs.readFileSync(DATA_PATH));
}
function saveManhwas(data) {
  fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
}

// Get all manhwas
app.get('/api/manhwas', (req, res) => {
  res.json(loadManhwas());
});

// Get single manhwa
app.get('/api/manhwas/:id', (req, res) => {
  const manhwa = loadManhwas().find(m => m.id === req.params.id);
  if (!manhwa) return res.status(404).json({ error: 'Not found' });
  res.json(manhwa);
});

// Admin: add new manhwa
app.post('/api/admin/manhwas', upload.single('cover'), (req, res) => {
  if (!isAuthenticated(req)) return res.status(401).json({ error: 'Unauthorized' });
  const { title, author } = req.body;
  const id = 'mh_' + Date.now();
  const cover = req.file ? '/' + req.file.path.replace(/\\/g, '/') : '';
  const manhwas = loadManhwas();
  const newManhwa = { id, title, author, cover, chapters: [] };
  manhwas.push(newManhwa);
  saveManhwas(manhwas);
  res.json(newManhwa);
});

// Admin: add new chapter
app.post('/api/admin/chapters', upload.array('images', 30), (req, res) => {
  if (!isAuthenticated(req)) return res.status(401).json({ error: 'Unauthorized' });
  const { manhwaId, title } = req.body;
  const manhwas = loadManhwas();
  const manhwa = manhwas.find(m => m.id === manhwaId);
  if (!manhwa) return res.status(404).json({ error: 'Manhwa not found' });
  const chapterId = 'ch_' + Date.now();
  const images = req.files ? req.files.map(f => '/' + f.path.replace(/\\/g, '/')) : [];
  const newChapter = { id: chapterId, title, images };
  manhwa.chapters.push(newChapter);
  saveManhwas(manhwas);
  res.json(newChapter);
});

// Admin: get all manhwas (with chapters) for admin
app.get('/api/admin/manhwas', (req, res) => {
  if (!isAuthenticated(req)) return res.status(401).json({ error: 'Unauthorized' });
  res.json(loadManhwas());
});

// Sample data on first run
if (!fs.existsSync(DATA_PATH)) {
  const sample = [
    {
      id: "mh_sample",
      title: "Sample Manhwa",
      author: "Sample Author",
      cover: "/uploads/sample/cover.jpg",
      chapters: [
        {
          id: "ch_sample1",
          title: "Chapter 1",
          images: [
            "/uploads/sample/ch1/01.jpg",
            "/uploads/sample/ch1/02.jpg"
          ]
        }
      ]
    }
  ];
  saveManhwas(sample);

  // copy sample images
  const sampleDir = path.join(__dirname, 'uploads/sample/ch1');
  fs.mkdirSync(sampleDir, { recursive: true });
  // You should add your own sample images to backend/uploads/sample/ch1/01.jpg and 02.jpg
  // For now, create placeholder text images:
  const { createCanvas } = require('canvas');
  function makeImage(text, outpath) {
    const canvas = createCanvas(600, 900);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, 600, 900);
    ctx.fillStyle = '#333'; ctx.font = 'bold 40px sans-serif';
    ctx.fillText(text, 80, 450);
    const buffer = canvas.toBuffer('image/jpeg');
    fs.writeFileSync(outpath, buffer);
  }
  makeImage('Sample 01', path.join(sampleDir, '01.jpg'));
  makeImage('Sample 02', path.join(sampleDir, '02.jpg'));
  const coverDir = path.join(__dirname, 'uploads/sample');
  fs.mkdirSync(coverDir, { recursive: true });
  makeImage('Sample Cover', path.join(coverDir, 'cover.jpg'));
}

app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));